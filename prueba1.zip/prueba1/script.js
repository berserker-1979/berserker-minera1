function verFuncionalidades() {
    alert("Aquí iría la sección de funcionalidades.");
}

function ingresarSistema() {
    alert("Aquí iría el inicio de sesión.");
}
